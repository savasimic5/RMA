package com.example.projektamb26;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupCard(R.id.cardEnglish, "Engleski");
        setupCard(R.id.cardSpanish, "Španski");
        setupCard(R.id.cardFrench, "Francuski");
        setupCard(R.id.cardGerman, "Nemački");
    }

    private void setupCard(int id, String jezik) {
        findViewById(id).setOnClickListener(v -> {
            Intent intent = new Intent(this, LevelSelectionActivity.class);
            intent.putExtra("JEZIK", jezik);
            startActivity(intent);
        });
    }
}