package com.example.projektamb26;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class QuizActivity extends AppCompatActivity {
    private TextView tvPitanje, tvFeedback;
    private Button btn1, btn2, btnSledeci, btnNazad;
    private ProgressBar progressBar;
    private LinearLayout layoutKraj, layoutOdgovori;
    private RelativeLayout quizRoot;
    private CardView cardPitanje;

    private String[][] pitanja;
    private int index = 0, nivo;
    private String jezik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);


        tvPitanje = findViewById(R.id.tvPitanje);
        tvFeedback = findViewById(R.id.tvFeedback);
        btn1 = findViewById(R.id.btnOpcija1);
        btn2 = findViewById(R.id.btnOpcija2);
        btnSledeci = findViewById(R.id.btnSledeci);
        btnNazad = findViewById(R.id.btnNazad);
        progressBar = findViewById(R.id.quizProgressBar);
        layoutKraj = findViewById(R.id.layoutKraj);
        layoutOdgovori = findViewById(R.id.layoutOdgovori);
        quizRoot = findViewById(R.id.quizRoot);
        cardPitanje = findViewById(R.id.cardPitanje);


        jezik = getIntent().getStringExtra("JEZIK");
        nivo = getIntent().getIntExtra("NIVO", 1);


        primeniDizajnKviz();
        ucitajSadrzaj();


        btn1.setOnClickListener(v -> proveri(btn1.getText().toString()));
        btn2.setOnClickListener(v -> proveri(btn2.getText().toString()));

        btnSledeci.setOnClickListener(v -> {
            if (nivo < 5) {
                nivo++;
                index = 0;
                ucitajSadrzaj();
            } else {
                finish();
            }
        });

        btnNazad.setOnClickListener(v -> finish());
    }

    private void primeniDizajnKviz() {
        if ("Engleski".equals(jezik)) {
            quizRoot.setBackgroundColor(Color.WHITE);
            tvPitanje.setTextColor(Color.parseColor("#CF142B"));
            btn1.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#CF142B")));
            btn2.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#CF142B")));
            cardPitanje.setCardBackgroundColor(Color.parseColor("#F5F5F5"));
        } else if ("Španski".equals(jezik)) {
            quizRoot.setBackgroundColor(Color.parseColor("#AA151B"));
            tvPitanje.setTextColor(Color.parseColor("#F1BF00"));
            btn1.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1BF00")));
            btn1.setTextColor(Color.BLACK);
            btn2.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1BF00")));
            btn2.setTextColor(Color.BLACK);
            cardPitanje.setCardBackgroundColor(Color.WHITE);
        } else if ("Francuski".equals(jezik)) {
            quizRoot.setBackgroundColor(Color.parseColor("#0055A4"));
            tvPitanje.setTextColor(Color.parseColor("#0055A4"));
            btn1.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            btn1.setTextColor(Color.parseColor("#0055A4"));
            btn2.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            btn2.setTextColor(Color.parseColor("#0055A4"));
            cardPitanje.setCardBackgroundColor(Color.WHITE);
        } else if ("Nemački".equals(jezik)) {
            quizRoot.setBackgroundColor(Color.parseColor("#FFCE00"));
            tvPitanje.setTextColor(Color.BLACK);
            btn1.setBackgroundTintList(ColorStateList.valueOf(Color.BLACK));
            btn1.setTextColor(Color.WHITE);
            btn2.setBackgroundTintList(ColorStateList.valueOf(Color.BLACK));
            btn2.setTextColor(Color.WHITE);
            cardPitanje.setCardBackgroundColor(Color.WHITE);
        }
    }

    private void ucitajSadrzaj() {
        generisiPitanja();
        layoutKraj.setVisibility(View.GONE);
        layoutOdgovori.setVisibility(View.VISIBLE);
        osveziUI();
    }

    private void osveziUI() {
        if (index < pitanja.length) {
            tvPitanje.setText(pitanja[index][0]);
            btn1.setText(pitanja[index][1]);
            btn2.setText(pitanja[index][2]);
            progressBar.setProgress(index);
            tvFeedback.setText("");
            btn1.setEnabled(true);
            btn2.setEnabled(true);
        } else {

            tvPitanje.setText("NIVO ZAVRŠEN!");
            layoutOdgovori.setVisibility(View.GONE);
            layoutKraj.setVisibility(View.VISIBLE);
            if (nivo == 5) btnSledeci.setVisibility(View.GONE);
        }
    }

    private void proveri(String odgovor) {
        btn1.setEnabled(false);
        btn2.setEnabled(false);

        if (odgovor.equals(pitanja[index][1])) {
            tvFeedback.setText("TAČNO!");
            tvFeedback.setTextColor(Color.GREEN);
            new Handler().postDelayed(() -> {
                index++;
                osveziUI();
            }, 1000);
        } else {
            tvFeedback.setText("NETAČNO! PROBAJ PONOVO.");
            tvFeedback.setTextColor(Color.RED);
            new Handler().postDelayed(() -> {
                tvFeedback.setText("");
                btn1.setEnabled(true);
                btn2.setEnabled(true);
            }, 800);
        }
    }

    private void generisiPitanja() {
        if ("Engleski".equals(jezik)) {
            if (nivo == 1) pitanja = new String[][]{{"'Apple' je jabuka?", "Tačno", "Netačno"}, {"Hvala?", "Thank you", "Please"}, {"'Water' je vatra?", "Netačno", "Tačno"}, {"Yes?", "Da", "Ne"}, {"Friend?", "Prijatelj", "Neprijatelj"}};
            else if (nivo == 2) pitanja = new String[][]{{"Račun?", "Bill", "Ball"}, {"'Menu' je jelovnik?", "Tačno", "Netačno"}, {"Coffee with milk?", "Kafa sa mlekom", "Čaj"}, {"Sto?", "Table", "Chair"}, {"Naručiti?", "Order", "Offer"}};
            else if (nivo == 3) pitanja = new String[][]{{"Levo?", "Left", "Right"}, {"Where is the station?", "Gde je stanica?", "Kako ste?"}, {"Excuse me?", "Izvinite", "Hvala"}, {"Ulica?", "Street", "Park"}, {"Bus stop?", "Autobusko stajalište", "Škola"}};
            else if (nivo == 4) pitanja = new String[][]{{"Aerodrom?", "Airport", "Plane"}, {"Pasoš?", "Passport", "Key"}, {"Let?", "Flight", "Road"}, {"Hotel?", "Hotel", "House"}, {"Kofer?", "Suitcase", "Bag"}};
            else pitanja = new String[][]{{"My name is...", "Zovem se...", "Imam..."}, {"I don't understand", "Ne razumem", "Razumem"}, {"How much?", "Koliko košta?", "Ko je to?"}, {"I am lost", "Izgubljen sam", "Gladan sam"}, {"Nice day", "Prijatan dan", "Laku noć"}};
        }
        else if ("Španski".equals(jezik)) {
            if (nivo == 1) pitanja = new String[][]{{"Hola?", "Zdravo", "Doviđenja"}, {"Gracias?", "Hvala", "Molim"}, {"Agua?", "Voda", "Vatra"}, {"Sí?", "Da", "Ne"}, {"Amigo?", "Prijatelj", "Brat"}};
            else if (nivo == 2) pitanja = new String[][]{{"La cuenta?", "Račun", "Meni"}, {"Mesa?", "Sto", "Stolica"}, {"Café con leche?", "Kafa sa mlekom", "Voda"}, {"Comida?", "Hrana", "Piće"}, {"Pan?", "Hleb", "Mleko"}};
            else if (nivo == 3) pitanja = new String[][]{{"Izquierda?", "Levo", "Desno"}, {"¿Dónde está?", "Gde se nalazi?", "Šta je?"}, {"Calle?", "Ulica", "Put"}, {"Estación?", "Stanica", "Muzej"}, {"Perdón?", "Izvinite", "Zdravo"}};
            else if (nivo == 4) pitanja = new String[][]{{"Aeropuerto?", "Aerodrom", "Voz"}, {"Pasaporte?", "Pasoš", "Karta"}, {"Vuelo?", "Let", "Put"}, {"Hotel?", "Hotel", "Soba"}, {"Maleta?", "Torba/Kofer", "Novčanik"}};
            else pitanja = new String[][]{{"Me llamo...", "Zovem se...", "Imam..."}, {"No entiendo", "Ne razumem", "Razumem"}, {"¿Cuánto cuesta?", "Koliko košta?", "Gde je?"}, {"Estoy perdido", "Izgubljen sam", "Srećan sam"}, {"Buenos días", "Dobro jutro", "Laku noć"}};
        }
        else if ("Francuski".equals(jezik)) {
            if (nivo == 1) pitanja = new String[][]{{"Bonjour?", "Zdravo", "Doviđenja"}, {"Merci?", "Hvala", "Molim"}, {"Eau?", "Voda", "Vino"}, {"Oui?", "Da", "Ne"}, {"Ami?", "Prijatelj", "Neprijatelj"}};
            else if (nivo == 2) pitanja = new String[][]{{"L'addition?", "Račun", "Meni"}, {"Table?", "Sto", "Vrata"}, {"Café au lait?", "Kafa sa mlekom", "Sok"}, {"Pain?", "Hleb", "Sir"}, {"Vin?", "Vino", "Pivo"}};
            else if (nivo == 3) pitanja = new String[][]{{"À gauche?", "Levo", "Desno"}, {"Gare?", "Stanica", "Aerodrom"}, {"Rue?", "Ulica", "Trg"}, {"Bus?", "Autobus", "Voz"}, {"Pardon?", "Izvinite", "Hvala"}};
            else if (nivo == 4) pitanja = new String[][]{{"Aéroport?", "Aerodrom", "Luka"}, {"Passeport?", "Pasoš", "Novac"}, {"Vol?", "Let", "Auto"}, {"Hôtel?", "Hotel", "Kamp"}, {"Valise?", "Kofer", "Ranac"}};
            else pitanja = new String[][]{{"Je m'appelle...", "Zovem se...", "Ja sam..."}, {"Je ne comprends pas", "Ne razumem", "Razumem"}, {"C'est combien?", "Koliko košta?", "Šta je to?"}, {"Je suis perdu", "Izgubljen sam", "Dobro sam"}, {"Bonne journée", "Prijatan dan", "Laku noć"}};
        }
        else if ("Nemački".equals(jezik)) {
            if (nivo == 1) pitanja = new String[][]{{"Hallo?", "Zdravo", "Ćao"}, {"Danke?", "Hvala", "Izvoli"}, {"Wasser?", "Voda", "Sok"}, {"Ja?", "Da", "Ne"}, {"Freund?", "Prijatelj", "Otac"}};
            else if (nivo == 2) pitanja = new String[][]{{"Rechnung?", "Račun", "Katalog"}, {"Tisch?", "Sto", "Prozor"}, {"Kaffee?", "Kafa", "Čaj"}, {"Essen?", "Hrana", "Piće"}, {"Milch?", "Mleko", "Jogurt"}};
            else if (nivo == 3) pitanja = new String[][]{{"Links?", "Levo", "Desno"}, {"Bahnhof?", "Stanica", "Pijaca"}, {"Straße?", "Ulica", "Most"}, {"Halt?", "Stani", "Kreni"}, {"Entschuldigung?", "Izvinite", "Molim"}};
            else if (nivo == 4) pitanja = new String[][]{{"Flughafen?", "Aerodrom", "Garaža"}, {"Pass?", "Pasoš", "Lična karta"}, {"Flug?", "Let", "Vožnja"}, {"Hotel?", "Hotel", "Apartman"}, {"Koffer?", "Kofer", "Ključ"}};
            else pitanja = new String[][]{{"Ich heiße...", "Zovem se...", "On se zove..."}, {"Ich verstehe nicht", "Ne razumem", "Znam"}, {"Was kostet?", "Koliko košta?", "Ko je?"}, {"Verlaufen?", "Izgubljen", "Nađen"}, {"Guten Tag", "Dobar dan", "Laku noć"}};
        }
        progressBar.setMax(pitanja.length);
    }
}