package com.example.projektamb26;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LevelSelectionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_levels);

        String jezik = getIntent().getStringExtra("JEZIK");
        TextView tvTitle = findViewById(R.id.tvLevelTitle);
        LinearLayout root = findViewById(R.id.levelsRoot);
        tvTitle.setText(jezik);

        int[] ids = {R.id.btnLevel1, R.id.btnLevel2, R.id.btnLevel3, R.id.btnLevel4, R.id.btnLevel5};
        Button[] dugmad = new Button[5];
        for(int i=0; i<5; i++) dugmad[i] = findViewById(ids[i]);


        if ("Engleski".equals(jezik)) {
            root.setBackgroundColor(Color.WHITE);
            tvTitle.setTextColor(Color.parseColor("#CF142B"));
            postaviDugmad(dugmad, "#CF142B", "#FFFFFF");
        } else if ("Španski".equals(jezik)) {
            root.setBackgroundColor(Color.parseColor("#AA151B"));
            tvTitle.setTextColor(Color.parseColor("#F1BF00"));
            postaviDugmad(dugmad, "#F1BF00", "#000000");
        } else if ("Francuski".equals(jezik)) {
            root.setBackgroundColor(Color.parseColor("#0055A4"));
            tvTitle.setTextColor(Color.WHITE);
            postaviDugmad(dugmad, "#FFFFFF", "#0055A4");
        } else if ("Nemački".equals(jezik)) {
            root.setBackgroundColor(Color.parseColor("#FFCE00"));
            tvTitle.setTextColor(Color.BLACK);
            postaviDugmad(dugmad, "#000000", "#FFFFFF");
        }

        for (int i = 0; i < 5; i++) {
            final int nivo = i + 1;
            dugmad[i].setText("NIVO " + nivo);
            dugmad[i].setOnClickListener(v -> {
                Intent intent = new Intent(this, QuizActivity.class);
                intent.putExtra("JEZIK", jezik);
                intent.putExtra("NIVO", nivo);
                startActivity(intent);
            });
        }
    }

    private void postaviDugmad(Button[] dugmad, String bojaPozadine, String bojaTeksta) {
        for (Button b : dugmad) {
            b.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(bojaPozadine)));
            b.setTextColor(Color.parseColor(bojaTeksta));
        }
    }
}